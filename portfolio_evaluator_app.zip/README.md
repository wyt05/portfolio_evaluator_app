# portfolio_evaluator_app
 An app to stonks
Step 1: To install the dependencies, type: pip install -r requirements.txt
Step 2: To run the app, just type: streamlit run app.py on the console.